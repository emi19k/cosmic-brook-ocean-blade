//#region node_modules/.nitro/vite/services/ssr/assets/model-8XJth7je.js
var VENUE_MIN = 3;
function mean(values) {
	if (values.length === 0) return 0;
	return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function poisson(k, lambda) {
	if (k < 0) return 0;
	if (lambda <= 0) return k === 0 ? 1 : 0;
	let log = -lambda;
	for (let i = 1; i <= k; i++) log += Math.log(lambda) - Math.log(i);
	return Math.exp(log);
}
function pickAvg(specific, n, overall) {
	if (n >= VENUE_MIN) return {
		value: specific,
		specific: true
	};
	return {
		value: overall,
		specific: false
	};
}
function summarizeTeam(team, matches) {
	const home = matches.filter((match) => match.home);
	const away = matches.filter((match) => !match.home);
	return {
		team,
		matches,
		forAvg: mean(matches.map((match) => match.cornersFor)),
		againstAvg: mean(matches.map((match) => match.cornersAgainst)),
		homeForAvg: mean(home.map((match) => match.cornersFor)),
		homeForN: home.length,
		awayForAvg: mean(away.map((match) => match.cornersFor)),
		awayForN: away.length,
		homeAgainstAvg: mean(home.map((match) => match.cornersAgainst)),
		homeAgainstN: home.length,
		awayAgainstAvg: mean(away.map((match) => match.cornersAgainst)),
		awayAgainstN: away.length
	};
}
function expectSide(attack, defense, venue) {
	const attackPick = venue === "home" ? pickAvg(attack.homeForAvg, attack.homeForN, attack.forAvg) : pickAvg(attack.awayForAvg, attack.awayForN, attack.forAvg);
	const concedePick = venue === "home" ? pickAvg(defense.homeAgainstAvg, defense.homeAgainstN, defense.againstAvg) : pickAvg(defense.awayAgainstAvg, defense.awayAgainstN, defense.againstAvg);
	return {
		expected: (attackPick.value + concedePick.value) / 2,
		attackAvg: attackPick.value,
		concedeAvg: concedePick.value,
		attackSpecific: attackPick.specific,
		concedeSpecific: concedePick.specific
	};
}
function centralBand(distribution) {
	const mode = distribution.reduce((best, row) => row.probability > best.probability ? row : best);
	let from = mode.total;
	let to = mode.total;
	let probability = mode.probability;
	while (to - from < 4 && probability < .5) {
		const left = distribution.find((row) => row.total === from - 1)?.probability ?? -1;
		const right = distribution.find((row) => row.total === to + 1)?.probability ?? -1;
		if (right < 0 && left < 0) break;
		if (right >= left) {
			to += 1;
			probability += right;
		} else {
			from -= 1;
			probability += left;
		}
	}
	return {
		from,
		to,
		probability
	};
}
function projectMatch(home, away) {
	const homeSide = expectSide(home, away, "home");
	const awaySide = expectSide(away, home, "away");
	const expectedHome = homeSide.expected;
	const expectedAway = awaySide.expected;
	const expectedTotal = expectedHome + expectedAway;
	const raw = Array.from({ length: 23 }, (_, total) => ({
		total,
		probability: poisson(total, expectedTotal)
	}));
	const mass = raw.reduce((sum, row) => sum + row.probability, 0) || 1;
	const distribution = raw.map((row) => ({
		total: row.total,
		probability: row.probability / mass
	}));
	const atLeast = [
		6,
		7,
		8,
		9,
		10,
		11,
		12,
		13
	].map((goals) => ({
		atLeast: goals,
		probability: distribution.filter((row) => row.total >= goals).reduce((sum, row) => sum + row.probability, 0)
	}));
	const lines = [
		6.5,
		7.5,
		8.5,
		9.5,
		10.5,
		11.5,
		12.5
	].map((line) => {
		const over = distribution.filter((row) => row.total > line).reduce((sum, row) => sum + row.probability, 0);
		return {
			line,
			over,
			under: 1 - over
		};
	});
	const headlineAtLeast = Math.max(1, Math.round(expectedTotal));
	const headlineProbability = distribution.filter((row) => row.total >= headlineAtLeast).reduce((sum, row) => sum + row.probability, 0);
	return {
		expectedHome,
		expectedAway,
		expectedTotal,
		home: homeSide,
		away: awaySide,
		distribution,
		atLeast,
		lines,
		band: centralBand(distribution),
		headlineAtLeast,
		headlineProbability
	};
}
function venueRows(matches, venue) {
	const rows = matches.filter((match) => venue === "home" ? match.home : !match.home);
	return rows.length >= VENUE_MIN ? rows : matches;
}
function cardSide(matches) {
	const usable = matches.filter((match) => match.cardsFor >= 0);
	return {
		sample: usable.length,
		commitAvg: mean(usable.map((match) => match.cardsFor)),
		concedeAvg: mean(usable.map((match) => match.cardsAgainst)),
		yellowAvg: mean(usable.map((match) => match.yellowFor)),
		redAvg: mean(usable.map((match) => match.redFor)),
		recent: usable.slice(0, 10)
	};
}
function readCards(homeMatches, awayMatches, meetings, referee) {
	const home = cardSide(homeMatches);
	const away = cardSide(awayMatches);
	const homeCommit = mean(venueRows(home.recent, "home").map((match) => match.cardsFor));
	const awayConcede = mean(venueRows(away.recent, "away").map((match) => match.cardsAgainst));
	const awayCommit = mean(venueRows(away.recent, "away").map((match) => match.cardsFor));
	const homeConcede = mean(venueRows(home.recent, "home").map((match) => match.cardsAgainst));
	const expectedHome = home.sample && away.sample ? (homeCommit + awayConcede) / 2 : 0;
	const expectedAway = home.sample && away.sample ? (awayCommit + homeConcede) / 2 : 0;
	return {
		enough: home.sample >= 4 && away.sample >= 4,
		expectedHome,
		expectedAway,
		expectedTotal: expectedHome + expectedAway,
		home,
		away,
		meetings,
		referee
	};
}
function shotSide(matches) {
	const usable = matches.filter((match) => match.shotsFor >= 0);
	const home = usable.filter((match) => match.home);
	const away = usable.filter((match) => !match.home);
	return {
		sample: usable.length,
		forAvg: mean(usable.map((match) => match.shotsFor)),
		againstAvg: mean(usable.map((match) => match.shotsAgainst)),
		homeForAvg: mean(home.map((match) => match.shotsFor)),
		homeForN: home.length,
		awayForAvg: mean(away.map((match) => match.shotsFor)),
		awayForN: away.length,
		homeAgainstAvg: mean(home.map((match) => match.shotsAgainst)),
		homeAgainstN: home.length,
		awayAgainstAvg: mean(away.map((match) => match.shotsAgainst)),
		awayAgainstN: away.length
	};
}
function shotRole(attack, defense, venue) {
	const attackPick = venue === "home" ? pickAvg(attack.homeForAvg, attack.homeForN, attack.forAvg) : pickAvg(attack.awayForAvg, attack.awayForN, attack.forAvg);
	const concedePick = venue === "home" ? pickAvg(defense.awayAgainstAvg, defense.awayAgainstN, defense.againstAvg) : pickAvg(defense.homeAgainstAvg, defense.homeAgainstN, defense.againstAvg);
	return {
		expected: attack.sample && defense.sample ? (attackPick.value + concedePick.value) / 2 : 0,
		attackAvg: attackPick.value,
		concedeAvg: concedePick.value,
		attackSpecific: attackPick.specific,
		concedeSpecific: concedePick.specific
	};
}
function readShots(homeMatches, awayMatches) {
	const home = shotSide(homeMatches);
	const away = shotSide(awayMatches);
	const homeRole = shotRole(home, away, "home");
	const awayRole = shotRole(away, home, "away");
	return {
		enough: home.sample >= 4 && away.sample >= 4,
		expectedHome: homeRole.expected,
		expectedAway: awayRole.expected,
		expectedTotal: homeRole.expected + awayRole.expected,
		home,
		away,
		homeRole,
		awayRole
	};
}
function rankShotPlayers(players) {
	return [...players].sort((a, b) => {
		if (b.games.length !== a.games.length) {
			if (a.games.length === 0) return 1;
			if (b.games.length === 0) return -1;
		}
		return b.average - a.average || b.games.length - a.games.length;
	});
}
//#endregion
export { summarizeTeam as a, readShots as i, rankShotPlayers as n, readCards as r, projectMatch as t };
